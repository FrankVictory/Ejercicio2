package Calificación;

public class Principal {
    public static void main(String[]args)
    {
        Promedio p=new Promedio();
        p.IngresarNombre();
        p.pideCalificaciones();
        p.MostrarNombre();
        p.mostrarCalificaciones();
        p.mostrarPromedio();
        p.mostrarNota();
        
    }
}