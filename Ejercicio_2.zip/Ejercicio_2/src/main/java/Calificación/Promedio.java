/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Calificación;
import java.util.Scanner;

public class Promedio {
       
    String nombre = "";
    double arreglocalif[]=new double[5];
    
    public void pideCalificaciones()
    {
       
        Scanner sc=new Scanner(System.in);
        System.out.println("Ingrese las 5 calificaciones");
        for(int i=0;i<arreglocalif.length;i++)
        {
            arreglocalif[i]=sc.nextDouble(); 
        }
       
    }
    public void mostrarCalificaciones()
    {
       int j=0;
        System.out.println("Las Calificaciones son: ");
        while (j<5)
        {
            System.out.println(arreglocalif[j]);
            j++;
        }
    }
    
    public float mostrarPromedio()
    {
        float promedioA = 0;
        int suma=0;
        
        for(int i=0; i<arreglocalif.length; i++)
        {
            suma+=arreglocalif[i];
        }
        
        promedioA+=(suma/arreglocalif.length);
        
        System.out.println("El promedio del alumno es: "+ promedioA);

        return promedioA;
        
    
    }
    
    public float mostrarNota()
    {
        float promedioA = 0;
        int suma=0;
        char Nota =' ';
        
        for(int i=0; i<arreglocalif.length; i++)
        {
            suma+=arreglocalif[i];
        }
        
        promedioA+=(suma/arreglocalif.length);
        
        if (promedioA<50)
        {
        Nota='F';
        }
        else if (promedioA<60)
        {
        Nota='E';
        }        
        else if (promedioA<70)
        {
        Nota='D';
        }        
        else if (promedioA<80)
        {
        Nota='C';
        }        
        else if (promedioA<90)
        {
        Nota='B';
        }
        else 
        {
        Nota='A';
        }
        
        System.out.println("La calificación del alumno es: "+ Nota);
        
        return Nota;
        
    
    }
        
    public void IngresarNombre()
    {
    System.out.println("Ingrese Nombre del Alumno: ");
        Scanner sc=new Scanner(System.in);
        {
            nombre=sc.next();  
        }
    }
    
    public void MostrarNombre()
    {
    System.out.println("Nombre del Alumno: " +nombre);
    }
}
